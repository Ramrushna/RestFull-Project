package com.spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServiceHateoasRestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServiceHateoasRestAppApplication.class, args);
	}

}
